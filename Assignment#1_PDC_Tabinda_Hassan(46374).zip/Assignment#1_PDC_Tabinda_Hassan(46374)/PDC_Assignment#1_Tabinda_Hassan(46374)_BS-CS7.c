#include <stdio.h>
#include <stdlib.h>
#include <time.h>

float getRandomFloat() {
    return (float)rand() / RAND_MAX;
}

int main() {
    long sizes[] = {100000, 500000, 1000000, 5000000, 
                    10000000, 50000000, 100000000, 
                    500000000, 1000000000};

    int n = sizeof(sizes) / sizeof(sizes[0]);
    srand(time(NULL)); 

    for (int i = 0; i < n; i++) {
        long size = sizes[i];

        clock_t start = clock();

        float *arr = (float *)malloc(size * sizeof(float));
        if (arr == NULL) {
            printf("Memory allocation failed for size %ld\n", size);
            continue;
        }

        for (long j = 0; j < size; j++) {
            arr[j] = getRandomFloat();
        }

        clock_t end = clock();

        double time_taken = (double)(end - start) / CLOCKS_PER_SEC;

        printf("Input Size: %ld \t Execution Time: %f seconds\n", size, time_taken);

        free(arr);
    }

    return 0;
}
