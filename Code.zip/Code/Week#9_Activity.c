#include <stdio.h>
#include <stdlib.h>
#include <omp.h>
#include <time.h>

#define ARRAY_SIZE 10000

int main() {
    int arr[ARRAY_SIZE];
    long i;
    long serial_sum = 0;

    // Initialize array with random numbers
    srand(time(NULL));
    for (i = 0; i < ARRAY_SIZE; i++) {
        arr[i] = rand() % 100 + 1; // random numbers 1-100
    }

    // --- Serial Sum ---
    double start_time = omp_get_wtime();
    for (i = 0; i < ARRAY_SIZE; i++) {
        serial_sum += arr[i];
    }
    double end_time = omp_get_wtime();
    double serial_time = end_time - start_time;
    printf("Serial Sum: %ld\n", serial_sum);
    printf("Time (Serial): %.6f seconds\n", serial_time);

    // --- Parallel Sum ---
    int num_threads_list[] = {4, 5, 10};
    int num_runs = 3;

    for (int run = 0; run < num_runs; run++) {
        int num_threads = num_threads_list[run];
        long parallel_sum = 0;

        start_time = omp_get_wtime();

        #pragma omp parallel for num_threads(num_threads) reduction(+:parallel_sum)
        for (i = 0; i < ARRAY_SIZE; i++) {
            parallel_sum += arr[i];
        }

        end_time = omp_get_wtime();
        double parallel_time = end_time - start_time;
        double speedup = serial_time / parallel_time;

        printf("\nThreads: %d\n", num_threads);
        printf("Parallel Sum: %ld\n", parallel_sum);
        printf("Time (Parallel): %.6f seconds\n", parallel_time);
        printf("Speedup: %.2fx\n", speedup);
    }

    return 0;
}
