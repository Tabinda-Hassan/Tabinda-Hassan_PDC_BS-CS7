#include <stdio.h>
#include <stdlib.h>
#include <mpi.h>
#include <time.h>
#include <unistd.h>  // for sleep()

int main(int argc, char** argv) {
    int rank, size;
    MPI_Init(&argc, &argv);
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);

    srand(time(NULL) + rank);

    const int MAX_USAGE = 2000; // threshold limit for total power
    int usage, total = 0;
    int command = 1; // 1 = ON, 0 = OFF
    int cycles = 5;  // simulate 5 time intervals

    // Appliance names (index = rank)
    char* devices[] = {"Smart Hub", "Air Conditioner", "Fridge", "Lights", "Washing Machine"};

    if (size < 2) {
        if (rank == 0)
            printf("Please run with at least 2 processes (1 hub + 1 device)\n");
        MPI_Finalize();
        return 0;
    }

    if (rank == 0) {
        // Rank 0 → Smart Hub
        printf("=== Smart Hub Started ===\n");

        for (int t = 1; t <= cycles; t++) {
            printf("\n🔁 Cycle %d:\n", t);
            total = 0;

            // Receive power usage from each device
            for (int i = 1; i < size; i++) {
                MPI_Recv(&usage, 1, MPI_INT, i, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
                printf("Received %d W from %s\n", usage, devices[i]);
                total += usage;
            }

            printf("Total Power Consumption = %d W\n", total);

            // Decision: if total > threshold → turn off some low priority devices
            for (int i = 1; i < size; i++) {
                if (total > MAX_USAGE && (i == 3 || i == 4)) {
                    // Lights or Washing Machine will be turned off first
                    command = 0;
                } else {
                    command = 1;
                }
                MPI_Send(&command, 1, MPI_INT, i, 0, MPI_COMM_WORLD);
            }

            printf("Commands sent based on threshold.\n");
            sleep(1); // simulate delay
        }

        printf("\n✅ Simulation complete. Smart Hub shutting down.\n");
    } 
    else {
        // Appliance processes
        for (int t = 1; t <= cycles; t++) {
            // Generate random usage for each cycle
            usage = rand() % 1000 + 100; // 100–1100 W
            MPI_Send(&usage, 1, MPI_INT, 0, 0, MPI_COMM_WORLD);
            
            // Receive command from hub
            MPI_Recv(&command, 1, MPI_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);

            if (command == 1)
                printf("[%s] Staying ON (Usage = %d W)\n", devices[rank], usage);
            else
                printf("[%s] Turned OFF to save energy (Usage = %d W)\n", devices[rank], usage);
            
            sleep(1);
        }
    }

    MPI_Finalize();
    return 0;
}
