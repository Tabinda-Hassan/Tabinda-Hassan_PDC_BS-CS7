#include <stdio.h>
#include <pthread.h>
#include <semaphore.h>
#include <unistd.h>

sem_t printers;   // semaphore

void* print_job(void* arg) {
    int id = *(int*)arg;

    sem_wait(&printers);   // request a printer
    printf("Employee %d is printing...\n", id);
    sleep(2);              // simulate time taken to print
    printf("Employee %d finished printing.\n", id);
    sem_post(&printers);   // release printer

    return NULL;
}

int main() {
    pthread_t employees[4];
    int ids[4] = {1,2,3,4};

    sem_init(&printers, 0, 2);   // 2 printers available

    for (int i = 0; i < 4; i++) {
        pthread_create(&employees[i], NULL, print_job, &ids[i]);
    }

    for (int i = 0; i < 4; i++) {
        pthread_join(employees[i], NULL);
    }

    sem_destroy(&printers);
    return 0;
}
