#include <stdio.h>
#include <pthread.h>

int balance = 0;               // shared resource
pthread_mutex_t lock;          // mutex lock

void* deposit(void* arg) {
    int amount = *(int*)arg;   // deposit amount

    pthread_mutex_lock(&lock);     // lock before accessing balance
    int temp = balance;
    temp = temp + amount; 
    balance = temp;
    printf("Deposited %d, New Balance = %d\n", amount, balance);
    pthread_mutex_unlock(&lock);   // unlock after done

    return NULL;
}

int main() {
    pthread_t t1, t2;
    int a1 = 100, a2 = 200;

    pthread_mutex_init(&lock, NULL);   // initialize mutex

    pthread_create(&t1, NULL, deposit, &a1);
    pthread_create(&t2, NULL, deposit, &a2);

    pthread_join(t1, NULL);
    pthread_join(t2, NULL);

    pthread_mutex_destroy(&lock);      // destroy mutex
    printf("Final Balance = %d\n", balance);

    return 0;
}
