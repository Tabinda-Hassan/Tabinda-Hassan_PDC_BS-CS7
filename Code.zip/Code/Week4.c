#include <stdio.h>
#include <pthread.h>

void* thread_func(void *arg){
    int* pid = (int*) arg;
    int id =*pid; 
    long lim = 100000;
        for(long i =0;i<lim;i++){
            printf("Thread No %d: Hellow World %ld\n", id, i);
        }
        return NULL;
}

int main(void){
    
    pthread_t t1, t2;
    int arg1 = 1;
    int arg2 = 2;
    //int ret1 = pthread_create( &t1, NULL, thread_func, (void*) &arg1);
    //int ret2 = pthread_create(&t2, NULL, thread_func, &arg2);
    //pthread_join(t1, NULL);
    //pthread_join(t2, NULL);
    thread_func(&arg1);
    thread_func(&arg2);
    return 0;
}