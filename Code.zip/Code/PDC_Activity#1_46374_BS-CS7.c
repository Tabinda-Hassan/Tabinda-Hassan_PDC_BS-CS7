#include <stdio.h>
#include <pthread.h>
#include <semaphore.h>
#include <unistd.h>

sem_t hair;

sem_t makeup;

void* customer(void* arg){
    int id = *((int*)arg);
    int service = id % 3;

    if (service == 0) {
        sem_wait(&hair);
        print("Customer: hair done",id);
        sleep(10);
        sem_post(&hair)
    }
    else if (service == 1) {
        sem_wait(&makeup)
        printf("Customer: makeup done", id)
        sleep(10)
        sem_post(&makeup)
    }
    else{
        sem_wait(&hair)
        printf("Customer: Hair done before makeup", id)
        sleep(10)
        sem_post(&hair)

        sem_wait(&makeup)
        printf("Customer: makeup done after hairstyle", id)
        sleep(10)
        sem_post(&makeup)
    }
}

int main ()
{
    pthread_t t[6]
    sem_init(&hair, 0 ,2)
    sem_init(&makeup, 0, 1)

    for(int i=0; i<6; i++)
    pthread_create(&t[i], NULL, customer, (void*)(long)(i+1))

    for (int i=0; i<6; i++)
    pthread_join(t[i], NULL);

    return 0;

}

