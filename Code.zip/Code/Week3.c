#include <stdio.h>
#include<time.h>
int main(void){
    clock_t start, end; 
    long double cpu_time;
    start = clock();
    long  x = 100000000;
    long y = 0;
    for (long i = 0;i<x;i++){
         y++;
    }
    printf("\nThe value is %ld\n", y);
    end = clock();

    cpu_time = (long double)(end-start)/CLOCKS_PER_SEC;
    printf("\n\nTotal Execution time %Lf\n\n", cpu_time);
    return 0;
}
