#include <mpi.h>
#include <iostream>
#include <string>

int main(int argc, char** argv) {
    MPI_Init(&argc, &argv);

    int rank, size, name_len;
    char hostname[MPI_MAX_PROCESSOR_NAME];

    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);
    MPI_Get_processor_name(hostname, &name_len);

    std::cout << "Hello from rank " << rank
              << " of " << size
              << " running on computer: " << hostname << std::endl;

    // Example: Let rank 0 send a message to rank 1
    if (size >= 2) {
        if (rank == 0) {
            std::string message = "Hello from Computer 1!";
            MPI_Send(message.c_str(), message.size() + 1, MPI_CHAR, 1, 0, MPI_COMM_WORLD);
            std::cout << "Rank 0 sent a message to Rank 1.\n";
        } 
        else if (rank == 1) {
            char buffer[100];
            MPI_Recv(buffer, 100, MPI_CHAR, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
            std::cout << "Rank 1 received message: " << buffer << std::endl;
        }
    }

    MPI_Finalize();
    return 0;
}
