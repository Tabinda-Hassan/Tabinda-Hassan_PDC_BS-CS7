#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>

#define PORT 8080

int main() {
    int sock = 0;
    struct sockaddr_in serv_addr;
    char buffer[1024] = {0};
    char input[100];

    // 1️⃣ Create socket
    sock = socket(AF_INET, SOCK_STREAM, 0); //opens a communication line
    if (sock < 0) {
        perror("Socket creation failed");
        return 1;
    }

    serv_addr.sin_family = AF_INET;
    serv_addr.sin_port = htons(PORT);
    inet_pton(AF_INET, "127.0.0.1", &serv_addr.sin_addr);

    // 2️⃣ Connect
    if (connect(sock, (struct sockaddr*)&serv_addr, sizeof(serv_addr)) < 0) {
        perror("Connection failed");
        return 1;
    }

    // Receive question: how many numbers
    read(sock, buffer, sizeof(buffer));
    printf("Server: %s", buffer);
    fgets(input, sizeof(input), stdin);
    send(sock, input, strlen(input), 0);

    int n = atoi(input);

    // Receive request to enter n numbers
    memset(buffer, 0, sizeof(buffer));
    read(sock, buffer, sizeof(buffer));
    printf("Server: %s", buffer);

    for (int i = 0; i < n; i++) {
        printf("Enter number %d: ", i + 1);
        fgets(input, sizeof(input), stdin);
        send(sock, input, strlen(input), 0);
    }

    // Receive final result
    memset(buffer, 0, sizeof(buffer));
    read(sock, buffer, sizeof(buffer));
    printf("Server: %s", buffer);

    close(sock);
    return 0;
}
